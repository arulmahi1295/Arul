import React, { useState, useEffect } from 'react';
import { Filter, Search, MoreHorizontal, Clock, CheckCircle, AlertCircle, Beaker, Play, Check } from 'lucide-react';
import { storage } from '../data/storage';

const StatusBadge = ({ status }) => {
    const styles = {
        pending: 'bg-slate-100 text-slate-600',
        collected: 'bg-blue-50 text-blue-700',
        processing: 'bg-orange-50 text-orange-700',
        completed: 'bg-emerald-50 text-emerald-700',
        rejected: 'bg-rose-50 text-rose-700',
    };

    const labels = {
        pending: 'Pending Collection',
        collected: 'Sample Collected',
        processing: 'In Processing',
        completed: 'Results Ready',
        rejected: 'Rejected',
    };

    return (
        <span className={`px-2.5 py-1 rounded-full text-xs font-semibold ${styles[status] || styles.pending} border border-transparent`}>
            {labels[status] || status}
        </span>
    );
};

const Samples = () => {
    const [filter, setFilter] = useState('all');
    const [samples, setSamples] = useState([]);
    const [searchTerm, setSearchTerm] = useState('');

    useEffect(() => {
        loadSamples();
    }, []);

    const loadSamples = () => {
        const orders = storage.getOrders();
        // Map orders to sample format if needed, or just use orders directly.
        // We'll treat each order as a "Sample Batch" for simplicity.
        // Sort by date desc
        orders.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
        setSamples(orders);
    };

    const updateStatus = (orderId, newStatus) => {
        storage.updateOrder(orderId, { status: newStatus });
        loadSamples();
    };

    const filteredSamples = samples.filter(s => {
        const matchesFilter = filter === 'all' || s.status === filter;
        const matchesSearch =
            s.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
            s.patientId.toLowerCase().includes(searchTerm.toLowerCase());
        return matchesFilter && matchesSearch;
    });

    return (
        <div>
            <header className="mb-8 flex justify-between items-center">
                <div>
                    <h1 className="text-2xl font-bold text-slate-800">Sample Tracking</h1>
                    <p className="text-slate-500">Monitor sample status from collection to reporting.</p>
                </div>
                <button className="flex items-center px-4 py-2 bg-white border border-slate-300 rounded-lg text-slate-700 text-sm font-medium hover:bg-slate-50">
                    <Filter className="mr-2 h-4 w-4" /> Filter View
                </button>
            </header>

            {/* Status Overview */}
            <div className="grid grid-cols-4 gap-4 mb-8">
                {['pending', 'collected', 'processing', 'completed'].map(status => (
                    <button
                        key={status}
                        onClick={() => setFilter(filter === status ? 'all' : status)}
                        className={`p-4 rounded-xl border text-left transition-all ${filter === status ? 'bg-indigo-50 border-indigo-200 ring-1 ring-indigo-200' : 'bg-white border-slate-100 hover:border-slate-300'}`}
                    >
                        <span className="block text-xs uppercase font-bold text-slate-400 mb-1">{status}</span>
                        <span className="text-2xl font-bold text-slate-800">{samples.filter(s => s.status === status).length}</span>
                    </button>
                ))}
            </div>

            <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
                <div className="p-4 border-b border-slate-100 flex items-center justify-between">
                    <div className="relative max-w-md w-full">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                        <input
                            type="text"
                            placeholder="Search by Order ID, Patient Name..."
                            className="w-full pl-9 pr-4 py-2 rounded-lg bg-slate-50 border-none focus:ring-2 focus:ring-indigo-100 text-sm"
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                        />
                    </div>
                </div>

                <table className="w-full text-left border-collapse">
                    <thead className="bg-slate-50/50 text-slate-500 text-xs uppercase font-semibold">
                        <tr>
                            <th className="px-6 py-4">Sample / Order ID</th>
                            <th className="px-6 py-4">Patient</th>
                            <th className="px-6 py-4">Test(s)</th>
                            <th className="px-6 py-4">Status</th>
                            <th className="px-6 py-4">Date</th>
                            <th className="px-6 py-4 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                        {filteredSamples.length === 0 ? (
                            <tr>
                                <td colSpan="6" className="text-center py-12 text-slate-400">No samples found.</td>
                            </tr>
                        ) : (
                            filteredSamples.map(sample => (
                                <tr key={sample.id} className="hover:bg-slate-50/50 transition-colors">
                                    <td className="px-6 py-4 font-mono text-sm text-slate-600 font-medium">
                                        <div className="flex items-center">
                                            <Beaker className="h-4 w-4 mr-2 text-slate-400" />
                                            {sample.id}
                                        </div>
                                    </td>
                                    <td className="px-6 py-4">
                                        <span className="block text-sm font-medium text-slate-800">{sample.patientId}</span>
                                    </td>
                                    <td className="px-6 py-4 text-sm text-slate-600">
                                        <div className="max-w-[200px] truncate" title={sample.tests.map(t => t.name).join(', ')}>
                                            {sample.tests.map(t => t.name).join(', ')}
                                        </div>
                                    </td>
                                    <td className="px-6 py-4">
                                        <StatusBadge status={sample.status} />
                                    </td>
                                    <td className="px-6 py-4 text-sm text-slate-500 flex items-center">
                                        <Clock className="h-3 w-3 mr-1.5" />
                                        {new Date(sample.createdAt).toLocaleDateString()}
                                    </td>
                                    <td className="px-6 py-4 text-right">
                                        <div className="flex justify-end gap-2">
                                            {sample.status === 'pending' && (
                                                <button
                                                    onClick={() => updateStatus(sample.id, 'collected')}
                                                    className="p-1 px-2 bg-blue-50 text-blue-600 rounded text-xs font-semibold hover:bg-blue-100 transition-colors flex items-center"
                                                    title="Mark Collected"
                                                >
                                                    <CheckCircle className="h-3 w-3 mr-1" /> Collect
                                                </button>
                                            )}
                                            {sample.status === 'collected' && (
                                                <button
                                                    onClick={() => updateStatus(sample.id, 'processing')}
                                                    className="p-1 px-2 bg-orange-50 text-orange-600 rounded text-xs font-semibold hover:bg-orange-100 transition-colors flex items-center"
                                                    title="Process"
                                                >
                                                    <Play className="h-3 w-3 mr-1" /> Process
                                                </button>
                                            )}
                                            {sample.status === 'processing' && (
                                                <button
                                                    className="p-1 px-2 bg-slate-100 text-slate-400 rounded text-xs font-semibold cursor-not-allowed flex items-center"
                                                    title="Go to Result Entry"
                                                >
                                                    Pending Results
                                                </button>
                                            )}
                                        </div>
                                    </td>
                                </tr>
                            ))
                        )}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default Samples;
