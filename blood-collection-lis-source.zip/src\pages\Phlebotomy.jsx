import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Search, Plus, Trash2, Beaker, FileText, Printer, CheckCircle, Clock, History, Download } from 'lucide-react';
import { storage } from '../data/storage';
import { useDebounce } from '../hooks/useDebounce';

import { TEST_CATALOG } from '../data/testCatalog';

const MOCK_TESTS = TEST_CATALOG;

const Phlebotomy = () => {
    const location = useLocation();
    const navigate = useNavigate();
    const [searchTerm, setSearchTerm] = useState('');
    const debouncedSearchTerm = useDebounce(searchTerm, 300); // 300ms delay

    const [selectedTests, setSelectedTests] = useState([]);
    const [patientId, setPatientId] = useState('');
    const debouncedPatientId = useDebounce(patientId, 300); // 300ms delay

    const [paymentMode, setPaymentMode] = useState('Cash');
    const [paymentStatus, setPaymentStatus] = useState('Paid');
    const [discount, setDiscount] = useState(0);
    const [orderStatus, setOrderStatus] = useState('new'); // new, processing, completed
    const [currentOrder, setCurrentOrder] = useState(null);
    const [patientSearchResults, setPatientSearchResults] = useState([]);
    const [showPatientResults, setShowPatientResults] = useState(false);
    const [processingMode, setProcessingMode] = useState('In-House');
    const [outsourceLab, setOutsourceLab] = useState('');

    const OUTSOURCE_PARTNERS = [
        'Lal PathLabs',
        'Metropolis',
        'Thyrocare',
        'Redcliffe',
        'Max Lab',
        'Local Hospital Reference'
    ];

    // TAT Calculation Helper
    const calculateTAT = (tests) => {
        if (!tests || tests.length === 0) return null;

        let maxHours = 12; // Default baseline

        tests.forEach(test => {
            const cat = test.category ? test.category.toUpperCase() : '';
            if (cat.includes('MICROBIOLOGY') || cat.includes('CULTURE')) maxHours = Math.max(maxHours, 48);
            else if (cat.includes('IMMUNOLOGY') || cat.includes('SEROLOGY') || cat.includes('MOLECULAR')) maxHours = Math.max(maxHours, 24);
            else maxHours = Math.max(maxHours, 12); // Biochemistry, Hematology default
        });

        const reportDate = new Date();
        reportDate.setHours(reportDate.getHours() + maxHours);
        return {
            date: reportDate,
            hours: maxHours
        };
    };

    const tatInfo = calculateTAT(selectedTests);

    const [patientHistory, setPatientHistory] = useState([]);

    // Other existing state...

    useEffect(() => {
        if (patientId) {
            // Fetch history
            const allOrders = storage.getOrders();
            const history = allOrders
                .filter(o => o.patientId === patientId)
                .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
            setPatientHistory(history);
        } else {
            setPatientHistory([]);
        }
    }, [patientId]);

    useEffect(() => {
        if (debouncedPatientId && debouncedPatientId.length > 1) {
            const results = storage.searchPatients(debouncedPatientId);
            setPatientSearchResults(results);
            setShowPatientResults(true);
        } else {
            setShowPatientResults(false);
        }
    }, [debouncedPatientId]);

    useEffect(() => {
        if (location.state && location.state.patientId) {
            setPatientId(`${location.state.patientId} - ${location.state.patientName}`);
            if (location.state.paymentMode) {
                setPaymentMode(location.state.paymentMode);
            }
        }
    }, [location.state]);

    const filteredTests = MOCK_TESTS.filter(test =>
        test.name.toLowerCase().includes(debouncedSearchTerm.toLowerCase()) ||
        test.code.toLowerCase().includes(debouncedSearchTerm.toLowerCase())
    );

    const addTest = (test) => {
        if (!selectedTests.find(t => t.id === test.id)) {
            setSelectedTests([...selectedTests, test]);
        }
    };

    const removeTest = (testId) => {
        setSelectedTests(selectedTests.filter(t => t.id !== testId));
    };

    const calculateSubtotal = () => {
        return selectedTests.reduce((acc, curr) => acc + curr.price, 0);
    };

    const calculateTotal = () => {
        return Math.max(0, calculateSubtotal() - discount);
    };

    const handleCreateOrder = () => {
        if (!patientId || selectedTests.length === 0) return;
        setOrderStatus('processing');

        const orderData = {
            patientId: patientId,
            tests: selectedTests,
            tests: selectedTests,
            subtotal: calculateSubtotal(),
            discount: Number(discount),
            totalAmount: calculateTotal(),
            paymentMode: paymentMode,
            paymentStatus: paymentStatus,
            processingMode: processingMode,
            outsourceLab: processingMode === 'Outsource' ? outsourceLab : null,
            expectedReportDate: tatInfo ? tatInfo.date.toISOString() : null,
            status: 'pending'
        };

        const savedOrder = storage.saveOrder(orderData);
        setCurrentOrder(savedOrder);
        console.log('Order Saved:', savedOrder);

        // Simulate printing labels and order creation
        setTimeout(() => {
            setOrderStatus('completed');
        }, 1500);
    };

    const handleReset = () => {
        setSelectedTests([]);
        setPatientId('');
        setOrderStatus('new');
        setProcessingMode('In-House');
        setOutsourceLab('');
        setPaymentMode('Cash');
        setDiscount(0);
        setSearchTerm('');
        setCurrentOrder(null);
    };

    const openPrintWindow = (path) => {
        if (!currentOrder) return;
        // Open in new window
        window.open(`${path}`, '_blank');
        // We can't easily pass state to new window via window.open directly without query params or local storage, 
        // but react-router-dom navigate opens in same tab usually.
        // Workaround: We'll use navigate with storing in local storage temp or just use the current tab for simplicity for now,
        // OR better: use window.open and let the component fetch by ID from URL.
        // Implementation Plan actually said "link to success screen buttons to these new print views".
        // Let's use navigate for now to verify logic, or simply pass state if we stay in same tab.
        // User requirement: "generate customer bills and labels". 
        // Best UX: Open in new tab. 
        // Let's try navigate to new route, and the user can print from there.
        navigate(path, { state: { order: currentOrder } });
    };

    if (orderStatus === 'completed') {
        return (
            <div className="max-w-2xl mx-auto py-12 text-center">
                <div className="h-24 w-24 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-6">
                    <CheckCircle className="h-12 w-12 text-emerald-600" />
                </div>
                <h2 className="text-3xl font-bold text-slate-800 mb-2">Order Created Successfully!</h2>
                <p className="text-slate-500 mb-8">Order #{currentOrder?.id} has been queued for processing.</p>
                <div className="flex justify-center gap-4">
                    <button onClick={handleReset} className="px-6 py-3 bg-white border border-slate-300 rounded-xl text-slate-700 font-medium hover:bg-slate-50 transition-colors">
                        Start New Order
                    </button>
                    <button onClick={() => openPrintWindow('/print/labels')} className="px-6 py-3 bg-indigo-600 rounded-xl text-white font-medium hover:bg-indigo-700 transition-colors flex items-center">
                        <Printer className="mr-2 h-5 w-5" /> Print Labels
                    </button>
                    <button onClick={() => openPrintWindow('/print/invoice')} className="px-6 py-3 bg-slate-800 rounded-xl text-white font-medium hover:bg-slate-900 transition-colors flex items-center">
                        <FileText className="mr-2 h-5 w-5" /> Print Invoice
                    </button>
                </div>
            </div>
        );
    }

    return (
        <div className="flex gap-6 h-[calc(100vh-100px)]">
            {/* Left: Test Selection */}
            <div className="flex-1 flex flex-col">
                <header className="mb-6">
                    <h1 className="text-2xl font-bold text-slate-800">New Order</h1>
                    <p className="text-slate-500">Select tests to add to the requisition.</p>
                </header>

                <div className="bg-white rounded-2xl shadow-sm border border-slate-200 flex-1 flex flex-col overflow-hidden">
                    <div className="p-4 border-b border-slate-100">
                        <div className="relative">
                            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" />
                            <input
                                type="text"
                                placeholder="Search tests by name or code..."
                                className="w-full pl-10 pr-4 py-3 rounded-xl bg-slate-50 border-none focus:ring-2 focus:ring-indigo-100 outline-none text-slate-700 font-medium transition-all"
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                            />
                        </div>
                    </div>

                    <div className="flex-1 overflow-y-auto p-4 space-y-3">
                        {filteredTests.map(test => (
                            <div key={test.id} className="group flex items-center justify-between p-4 rounded-xl border border-slate-100 hover:border-indigo-100 hover:bg-indigo-50/30 transition-all cursor-pointer" onClick={() => addTest(test)}>
                                <div className="flex items-center">
                                    <div className={`h-10 w-10 rounded-lg ${test.color} flex items-center justify-center font-bold text-xs mr-4`}>
                                        {test.code}
                                    </div>
                                    <div>
                                        <h3 className="font-semibold text-slate-800">{test.name}</h3>
                                        <p className="text-xs text-slate-500 font-medium bg-slate-100 inline-block px-2 py-0.5 rounded mt-1">{test.category}</p>
                                    </div>
                                </div>
                                <div className="flex items-center">
                                    <span className="font-bold text-slate-700 mr-4">₹{test.price}</span>
                                    <button className="h-8 w-8 rounded-full bg-slate-100 hover:bg-indigo-600 hover:text-white flex items-center justify-center transition-colors">
                                        <Plus className="h-5 w-5" />
                                    </button>
                                </div>
                            </div>
                        ))}
                        {filteredTests.length === 0 && (
                            <div className="text-center py-12 text-slate-400">
                                <Beaker className="h-12 w-12 mx-auto mb-3 opacity-20" />
                                <p>No tests found matching "{searchTerm}"</p>
                            </div>
                        )}
                    </div>
                </div>
            </div>

            {/* Right: Order Summary */}
            <div className="w-96 flex flex-col">
                <div className="bg-white rounded-2xl shadow-sm border border-slate-200 flex flex-col h-full overflow-hidden">
                    <div className="p-6 border-b border-slate-100 bg-slate-50/50">
                        <h2 className="font-bold text-slate-800 flex items-center">
                            <FileText className="h-5 w-5 mr-2 text-indigo-600" />
                            Requisition Summary
                        </h2>
                    </div>

                    <div className="p-4 border-b border-slate-100 relative">
                        <label className="block text-xs font-semibold text-slate-500 mb-1 uppercase tracking-wider">Patient ID / Name</label>
                        <input
                            type="text"
                            placeholder="Search Patient (ID, Name, Phone)"
                            className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 outline-none text-sm transition-all"
                            value={patientId}
                            onChange={(e) => setPatientId(e.target.value)}
                            onFocus={() => {
                                if (patientId.length > 1) setShowPatientResults(true);
                            }}
                            onBlur={() => {
                                // Delay hide to allow click
                                setTimeout(() => setShowPatientResults(false), 200);
                            }}
                        />
                        {showPatientResults && patientSearchResults.length > 0 && (
                            <div className="absolute left-4 right-4 top-[70px] bg-white rounded-xl shadow-xl border border-slate-100 max-h-60 overflow-y-auto z-50">
                                {patientSearchResults.map(p => (
                                    <div
                                        key={p.id}
                                        className="p-3 hover:bg-slate-50 cursor-pointer border-b border-slate-50 last:border-none"
                                        onMouseDown={(e) => {
                                            e.preventDefault(); // Prevent focus loss on mouse down if needed, or just let it happen naturally after
                                            setPatientId(`${p.id} - ${p.fullName}`);
                                            setShowPatientResults(false);
                                        }}
                                    >
                                        <p className="font-semibold text-slate-800 text-sm">{p.fullName}</p>
                                        <div className="flex justify-between text-xs text-slate-500 mt-0.5">
                                            <span>{p.id}</span>
                                            <span>{p.phone}</span>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        )}

                        {/* Patient History Section */}
                        {patientId && patientHistory.length > 0 && (
                            <div className="mt-3 pt-3 border-t border-slate-100">
                                <div className="flex items-center justify-between mb-2">
                                    <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider flex items-center">
                                        <History className="h-3 w-3 mr-1" /> Recent Visits
                                    </h3>
                                    <span className="text-xs text-indigo-600 bg-indigo-50 px-1.5 py-0.5 rounded-full">{patientHistory.length}</span>
                                </div>
                                <div className="max-h-32 overflow-y-auto space-y-2 pr-1 custom-scrollbar">
                                    {patientHistory.slice(0, 5).map(order => (
                                        <div key={order.id} className="flex items-center justify-between p-2 bg-slate-50 rounded-lg border border-slate-200 text-xs">
                                            <div>
                                                <p className="font-semibold text-slate-700">{new Date(order.createdAt).toLocaleDateString()}</p>
                                                <p className="text-slate-500">{order.tests?.length || 0} Tests • ₹{order.totalAmount}</p>
                                            </div>
                                            <button
                                                onClick={() => {
                                                    // Use existing logic to open print window with this specific historical order
                                                    setCurrentOrder(order); // Temp set as current to use existing print logic helper if needed, OR better:
                                                    navigate('/print/invoice', { state: { order: order } });
                                                }}
                                                className="p-1.5 bg-white border border-slate-300 rounded hover:bg-slate-100 text-slate-600 transition-colors"
                                                title="Download Invoice"
                                            >
                                                <Download className="h-3.5 w-3.5" />
                                            </button>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        )}
                    </div>

                    <div className="flex-1 overflow-y-auto p-4 space-y-3">
                        {selectedTests.length === 0 ? (
                            <div className="text-center py-12 text-slate-400">
                                <p className="text-sm">No tests selected yet.</p>
                            </div>
                        ) : (
                            selectedTests.map(test => (
                                <div key={test.id} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg border border-slate-100">
                                    <div>
                                        <h4 className="font-medium text-slate-800 text-sm">{test.name}</h4>
                                        <span className="text-xs text-slate-500">{test.code}</span>
                                    </div>
                                    <div className="flex items-center">
                                        <span className="font-semibold text-slate-700 text-sm mr-3">₹{test.price}</span>
                                        <button onClick={() => removeTest(test.id)} className="text-slate-400 hover:text-rose-500 transition-colors">
                                            <Trash2 className="h-4 w-4" />
                                        </button>
                                    </div>
                                </div>
                            ))
                        )}
                    </div>

                    <div className="p-6 bg-slate-50 border-t border-slate-100">
                        <div className="mb-4 space-y-4">
                            {/* Processing Mode Selection */}
                            <div className="flex gap-4">
                                <div className="flex-1">
                                    <label className="block text-xs font-semibold text-slate-500 mb-1 uppercase tracking-wider">Processing Center</label>
                                    <select
                                        value={processingMode}
                                        onChange={(e) => setProcessingMode(e.target.value)}
                                        className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 outline-none text-sm bg-white font-medium"
                                    >
                                        <option value="In-House">In-House Lab</option>
                                        <option value="Outsource">Outsource / Tie-up</option>
                                    </select>
                                </div>
                                <div className="flex-1">
                                    {processingMode === 'Outsource' ? (
                                        <div className="animate-in fade-in slide-in-from-left-2">
                                            <label className="block text-xs font-semibold text-slate-500 mb-1 uppercase tracking-wider">Select Partner</label>
                                            <select
                                                value={outsourceLab}
                                                onChange={(e) => setOutsourceLab(e.target.value)}
                                                className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 outline-none text-sm bg-white"
                                            >
                                                <option value="">-- Select --</option>
                                                {OUTSOURCE_PARTNERS.map(partner => (
                                                    <option key={partner} value={partner}>{partner}</option>
                                                ))}
                                            </select>
                                        </div>
                                    ) : (
                                        <div className="opacity-50 pointer-events-none">
                                            <label className="block text-xs font-semibold text-slate-500 mb-1 uppercase tracking-wider">Lab Location</label>
                                            <input type="text" value="Main Branch (Internal)" disabled className="w-full px-3 py-2 rounded-lg border border-slate-200 bg-slate-100 text-sm" />
                                        </div>
                                    )}
                                </div>
                            </div>

                            <div className="flex gap-4">
                                <div className="flex-1">
                                    <label className="block text-xs font-semibold text-slate-500 mb-1 uppercase tracking-wider">Payment Mode</label>
                                    <select
                                        value={paymentMode}
                                        onChange={(e) => setPaymentMode(e.target.value)}
                                        className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 outline-none text-sm bg-white"
                                    >
                                        <option value="Cash">Cash</option>
                                        <option value="Card">Card</option>
                                        <option value="UPI">UPI / Online</option>
                                        <option value="Insurance">Insurance</option>
                                        <option value="Other">Other</option>
                                    </select>
                                </div>
                                <div className="flex-1">
                                    <label className="block text-xs font-semibold text-slate-500 mb-1 uppercase tracking-wider">Status</label>
                                    <select
                                        value={paymentStatus}
                                        onChange={(e) => setPaymentStatus(e.target.value)}
                                        className={`w-full px-3 py-2 rounded-lg border border-slate-300 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 outline-none text-sm bg-white font-medium ${paymentStatus === 'Pending' ? 'text-amber-600' : 'text-emerald-600'}`}
                                    >
                                        <option value="Paid">Paid</option>
                                        <option value="Pending">Pending</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div className="flex gap-4 mb-4 items-center">
                            <div className="flex-1">
                                <label className="block text-xs font-semibold text-slate-500 mb-1 uppercase tracking-wider">Discount (₹)</label>
                                <input
                                    type="number"
                                    min="0"
                                    value={discount}
                                    onChange={(e) => setDiscount(Math.max(0, parseInt(e.target.value) || 0))}
                                    className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 outline-none text-sm bg-white"
                                    placeholder="0"
                                />
                            </div>
                        </div>

                        <div className="space-y-2 mb-4 border-t border-slate-200 pt-4">
                            {tatInfo && (
                                <div className="bg-blue-50 p-3 rounded-lg flex items-start gap-3 mb-4 border border-blue-100">
                                    <Clock className="h-5 w-5 text-blue-600 flex-shrink-0 mt-0.5" />
                                    <div>
                                        <p className="text-xs font-bold text-blue-700 uppercase tracking-wide">Expected Report Delivery</p>
                                        <p className="text-sm font-medium text-blue-900">
                                            {tatInfo.date.toLocaleString('en-US', {
                                                weekday: 'short', month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit'
                                            })}
                                        </p>
                                        <p className="text-xs text-blue-600 mt-0.5">TAT: ~{tatInfo.hours} Hours</p>
                                    </div>
                                </div>
                            )}

                            <div className="flex justify-between items-center text-sm">
                                <span className="text-slate-500">Subtotal</span>
                                <span className="font-semibold text-slate-700">₹{calculateSubtotal()}</span>
                            </div>
                            {discount > 0 && (
                                <div className="flex justify-between items-center text-sm">
                                    <span className="text-slate-500">Discount</span>
                                    <span className="font-medium text-rose-600">- ₹{discount}</span>
                                </div>
                            )}
                            <div className="flex justify-between items-end pt-2 border-t border-slate-100">
                                <span className="text-slate-600 font-bold">Total Payable</span>
                                <span className="text-2xl font-bold text-slate-800">₹{calculateTotal()}</span>
                            </div>
                        </div>
                        <button
                            disabled={!patientId || selectedTests.length === 0}
                            onClick={handleCreateOrder}
                            className="w-full py-3 bg-indigo-600 text-white rounded-xl font-medium hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all shadow-lg shadow-indigo-200"
                        >
                            {orderStatus === 'processing' ? 'Processing...' : 'Create Order & Print Labels'}
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Phlebotomy;
